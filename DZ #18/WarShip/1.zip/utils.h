#ifndef UTILS_H
#define UTILS_H
#include <utility>
using namespace std;
namespace utils
{
    pair<int, int> ask_pos();
}
#endif // UTILS_H
